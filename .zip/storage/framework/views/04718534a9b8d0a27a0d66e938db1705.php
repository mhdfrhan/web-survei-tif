<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'icon', 'active' => false, 'routePattern', 'contentClasses' => 'mt-2 space-y-1']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'icon', 'active' => false, 'routePattern', 'contentClasses' => 'mt-2 space-y-1']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<li>
    <div 
        x-data="{ isExpanded: <?php echo e(request()->is($routePattern) ? 'true' : 'false'); ?> }" 
        class="flex flex-col relative group <?php echo e($active ? 'pl-4' : 'hover:pl-4'); ?> duration-300">

        
        <?php if($active): ?>
            <span class="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-cgreen-500 rounded"></span>
        <?php else: ?>
            <span class="opacity-0 invisible group-hover:opacity-100 group-hover:visible absolute left-0 top-1/2 -translate-y-1/2 w-1 h-0 group-hover:h-6 bg-cgreen-500 rounded duration-300"></span>
        <?php endif; ?>

        
        <button 
            type="button" 
            x-on:click="isExpanded = ! isExpanded" 
            aria-controls="<?php echo e(Str::slug($title)); ?>" 
            x-bind:aria-expanded="isExpanded ? 'true' : 'false'"
            class="inline-flex items-center gap-3 py-2.5 px-3 rounded-xl font-medium w-full border transition duration-150 ease-in-out relative
                <?php echo e($active ? 'text-navy-800 bg-white border-navy-500' : 'text-navy-200 hover:text-navy-800 hover:bg-white hover:border-navy-500 border-transparent'); ?>">

            <?php echo $icon; ?>


            <span class="mr-auto text-left"><?php echo e($title); ?></span>

            
            <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20"
                class="size-5 transition-transform shrink-0" 
                x-bind:class="isExpanded ? 'rotate-180' : 'rotate-0'">
                <path fill-rule="evenodd" d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd" />
            </svg>
        </button>

        
        <div x-cloak x-collapse x-show="isExpanded" aria-labelledby="<?php echo e(Str::slug($title)); ?>-btn" id="<?php echo e(Str::slug($title)); ?>">
            <ul class="<?php echo e($contentClasses); ?>">
                <?php echo e($slot); ?>

            </ul>
        </div>
    </div>
</li>
<?php /**PATH D:\Herd\survey-tif\resources\views/components/nav-dropdown.blade.php ENDPATH**/ ?>