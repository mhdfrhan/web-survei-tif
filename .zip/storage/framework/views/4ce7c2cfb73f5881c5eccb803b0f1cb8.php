<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $classes =
        $active ?? false
            ? 'inline-flex items-center py-2.5 px-3 rounded-xl font-medium bg-white border border-navy-500 w-full relative text-navy-800'
            : 'inline-flex items-center py-2.5 px-3 rounded-xl font-medium leading-5 text-navy-200 hover:text-navy-800 hover:bg-white border border-transparent hover:border-navy-500 w-full focus:outline-none transition duration-150 ease-in-out relative';
?>

<div class="relative group">
    <?php if($active ?? false): ?>
        <span class="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-cgreen-500 rounded"></span>
    <?php else: ?>
        <span
            class="opacity-0 invisible group-hover:opacity-100 group-hover:visible absolute left-0 top-1/2 -translate-y-1/2 w-1 h-0 group-hover:h-6 bg-cgreen-500 rounded duration-300"></span>
    <?php endif; ?>
    <div class="<?php echo e($active ?? false ? 'pl-4' : 'hover:pl-4'); ?> duration-300">
        <a <?php echo e($attributes->merge(['class' => $classes])); ?>>
            <?php echo e($slot); ?>

        </a>
    </div>
</div>
<?php /**PATH D:\Herd\survey-tif\resources\views/components/nav-link.blade.php ENDPATH**/ ?>