<x-main-layout>
	<x-slot name="title">Survey VMTS</x-slot>

	<livewire:home.survey.vmts />
</x-main-layout>