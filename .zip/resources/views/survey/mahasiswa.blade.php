<x-main-layout>
	<x-slot name="title">Survey Mahasiswa</x-slot>

	<livewire:home.survey.mahasiswa />
</x-main-layout>