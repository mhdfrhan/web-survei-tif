<x-main-layout>
	<x-slot name="title">Survey Dosen</x-slot>

	<livewire:home.survey.dosen />
</x-main-layout>