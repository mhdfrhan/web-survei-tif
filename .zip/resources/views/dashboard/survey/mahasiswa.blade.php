<x-app-layout>
	<livewire:dashboard.survey.mahasiswa-form />
</x-app-layout>