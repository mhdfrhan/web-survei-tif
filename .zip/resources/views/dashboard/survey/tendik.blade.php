<x-app-layout>
	<livewire:dashboard.survey.tendik-form />
</x-app-layout>