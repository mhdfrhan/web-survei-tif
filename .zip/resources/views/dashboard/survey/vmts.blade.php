<x-app-layout>
    <livewire:dashboard.survey.vmts-form />
</x-app-layout>
