<x-app-layout>
	<livewire:dashboard.survey.dosen-form />
</x-app-layout>