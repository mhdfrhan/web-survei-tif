<x-app-layout>
	<livewire:dashboard.survey-data-list />
</x-app-layout>
