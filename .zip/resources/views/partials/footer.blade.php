<footer class="bg-navy-600 text-white py-4 mt-20">
	<x-container>
		<p class="text-center text-sm">Copyright &copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
	</x-container>
</footer>