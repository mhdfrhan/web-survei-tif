<div class="max-w-7xl mx-auto px-4 sm:px-6">
	{{ $slot }}
</div>